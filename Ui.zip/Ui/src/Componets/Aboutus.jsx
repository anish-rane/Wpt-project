import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';

export default function AboutUs() {
  return (
    <Container className="mt-4">
      <h2>About Us</h2>
      <Row>
        <Col sm={12} md={4}>
          <Card>
            <Card.Img variant="top" src="https://via.placeholder.com/150" />
            <Card.Body>
              <Card.Title>Anish Rane</Card.Title>
              <Card.Text>Project Manager</Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col sm={12} md={4}>
          <Card>
            <Card.Img variant="top" src="/assets/khursange.png" />
            <Card.Body>
              <Card.Title>Abhishek Khursange</Card.Title>
              <Card.Text>Lead Developer</Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col sm={12} md={4}>
          <Card>
            <Card.Img variant="top" src="olms\Ui\src\assets\Sakre.png" />
            <Card.Body>
              <Card.Title>Akash Sakhare</Card.Title>
              <Card.Text>UI/UX Designer</Card.Text>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}
